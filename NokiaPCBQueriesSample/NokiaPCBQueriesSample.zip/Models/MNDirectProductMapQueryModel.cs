﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Apttus.Lightsaber.Nokia.Pricing
{
    public class MNDirectProductMapQueryModel
    {
        public string Id { get; set; }

        public string NokiaCPQ_Product_Code__c { get; set; }

        public string NokiaCPQ_Product_Type__c { get; set; }
    }
}
