﻿namespace Apttus.Lightsaber.Nokia.Pricing
{
    public class PriceListQueryModel
    {
        public string Id { get; set; }

        public string PriceList_Type__c { get; set; }
    }
}
